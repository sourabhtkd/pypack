from .main import greet

if __name__ == '__main__':
    greet()
